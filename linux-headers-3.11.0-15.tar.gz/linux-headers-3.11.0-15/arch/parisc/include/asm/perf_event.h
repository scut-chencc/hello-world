#ifndef __ASM_PARISC_PERF_EVENT_H
#define __ASM_PARISC_PERF_EVENT_H

/* Empty, just to avoid compiling error */

#endif /* __ASM_PARISC_PERF_EVENT_H */
