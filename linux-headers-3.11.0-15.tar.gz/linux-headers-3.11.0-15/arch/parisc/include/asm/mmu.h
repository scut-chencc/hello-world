#ifndef _PARISC_MMU_H_
#define _PARISC_MMU_H_

/* On parisc, we store the space id here */
typedef unsigned long mm_context_t;

#endif /* _PARISC_MMU_H_ */
