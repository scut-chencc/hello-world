#ifndef _PARISC_TYPES_H
#define _PARISC_TYPES_H

#include <asm-generic/int-ll64.h>

#endif
