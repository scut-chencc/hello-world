#ifndef _PARISC_SIGINFO_H
#define _PARISC_SIGINFO_H

#include <asm-generic/siginfo.h>

#undef NSIGTRAP
#define NSIGTRAP	4

#endif
