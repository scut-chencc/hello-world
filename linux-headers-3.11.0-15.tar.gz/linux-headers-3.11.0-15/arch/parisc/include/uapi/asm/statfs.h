#ifndef _PARISC_STATFS_H
#define _PARISC_STATFS_H

#define __statfs_word long
#include <asm-generic/statfs.h>

#endif
