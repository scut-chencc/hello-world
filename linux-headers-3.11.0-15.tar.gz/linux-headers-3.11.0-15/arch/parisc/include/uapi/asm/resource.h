#ifndef _ASM_PARISC_RESOURCE_H
#define _ASM_PARISC_RESOURCE_H

#define _STK_LIM_MAX	10 * _STK_LIM
#include <asm-generic/resource.h>

#endif
