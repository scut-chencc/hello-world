
#ifndef _ASM_KMAP_TYPES_H
#define _ASM_KMAP_TYPES_H

#define KM_TYPE_NR 17

#endif
