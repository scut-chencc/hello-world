#ifndef _ASM_CPUTIME_H
#define _ASM_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* _ASM_CPUTIME_H */
