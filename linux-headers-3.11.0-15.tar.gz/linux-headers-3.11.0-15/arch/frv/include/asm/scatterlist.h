#ifndef _ASM_SCATTERLIST_H
#define _ASM_SCATTERLIST_H

#include <asm-generic/scatterlist.h>

#endif /* !_ASM_SCATTERLIST_H */
