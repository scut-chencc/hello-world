#ifndef _ASM_S390_TERMBITS_H
#define _ASM_S390_TERMBITS_H

#include <asm-generic/termbits.h>

#endif
