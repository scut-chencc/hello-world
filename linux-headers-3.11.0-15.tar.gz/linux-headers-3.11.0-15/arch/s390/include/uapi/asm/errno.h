/*
 *  S390 version
 *
 */

#ifndef _S390_ERRNO_H
#define _S390_ERRNO_H

#include <asm-generic/errno.h>

#endif
