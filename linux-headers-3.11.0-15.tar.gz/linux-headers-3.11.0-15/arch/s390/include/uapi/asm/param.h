#ifndef _ASMS390_PARAM_H
#define _ASMS390_PARAM_H

#include <asm-generic/param.h>

#endif /* _ASMS390_PARAM_H */
