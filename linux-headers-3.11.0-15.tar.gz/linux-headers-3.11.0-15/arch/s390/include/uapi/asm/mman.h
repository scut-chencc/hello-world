/*
 *  S390 version
 *
 *  Derived from "include/asm-i386/mman.h"
 */
#include <asm-generic/mman.h>
