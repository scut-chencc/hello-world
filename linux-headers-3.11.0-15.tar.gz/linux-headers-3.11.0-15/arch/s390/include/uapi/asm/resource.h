/*
 *  S390 version
 *
 *  Derived from "include/asm-i386/resources.h"
 */

#ifndef _S390_RESOURCE_H
#define _S390_RESOURCE_H

#include <asm-generic/resource.h>

#endif

