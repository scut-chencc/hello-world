#ifndef _ASM_S390_SOCKIOS_H
#define _ASM_S390_SOCKIOS_H

#include <asm-generic/sockios.h>

#endif
