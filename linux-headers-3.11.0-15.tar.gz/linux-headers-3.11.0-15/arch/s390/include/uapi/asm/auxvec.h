#ifndef __ASMS390_AUXVEC_H
#define __ASMS390_AUXVEC_H

#define AT_SYSINFO_EHDR		33

#endif
