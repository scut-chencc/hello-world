#include <asm-generic/scatterlist.h>

#define ARCH_HAS_SG_CHAIN
